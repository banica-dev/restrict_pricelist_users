# -*- coding: utf-8 -*-
{
    'name': 'Restrict Pricelist Users',
    'description': "",
    'version': '1.0.1',
    'author': 'Banica Daniel',
    'maintainers': ["banica-dev"],
    'license': 'OPL-1',
    'installable': True,
    'data': [
        'views/product_pricelist_views.xml',
        'security/pricelist_rules.xml',
    ],
    'category': 'Sale',
    'depends': ['base', 'sale'],
}
